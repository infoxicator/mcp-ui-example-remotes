export default function mount(el: HTMLElement): void;
