export * from './compiled-types/vueMounter';
export { default } from './compiled-types/vueMounter';